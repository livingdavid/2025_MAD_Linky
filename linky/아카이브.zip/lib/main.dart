import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'auth_gate.dart';
import 'linkUploadWithURL.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final ReceiveSharingIntent _rsi = ReceiveSharingIntent.instance;
  StreamSubscription? _intentSub;
  bool _hasOpened = false;
  String? _sharedText;

  @override
  void initState() {
    super.initState();

    // 앱 실행 중 공유 이벤트 수신
    _intentSub = _rsi.getMediaStream().listen((List<SharedMediaFile> value) {
      if (value.isNotEmpty) {
        _sharedText = value.first.path; // 텍스트(링크)에선 path 대신 value.first.text 가능
        _openUploadPage();
      }
    }, onError: (err) => print("공유 오류: $err"));

    // 앱 처음 실행된 경우 처리
    _rsi.getInitialMedia().then((List<SharedMediaFile> value) {
      if (value.isNotEmpty) {
        _sharedText = value.first.path;
        _openUploadPage();
      }
    });
  }

  @override
  void dispose() {
    _intentSub?.cancel();
    super.dispose();
  }

  void _openUploadPage() {
    if (mounted && _sharedText != null && !_hasOpened) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => LinkUploadPageWithURL(url: _sharedText!),
          ),
        );
        _hasOpened = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Linky',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      debugShowCheckedModeBanner: false,
      home: const AuthGate(),
    );
  }
}
